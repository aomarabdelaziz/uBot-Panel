<?php

return [
    'reset'     => 'Salasana on resetoitu!',
    'sent'      => 'Resetointilinkki lähetetty sähköpostitse!',
    'throttled' => 'Odota, ennen kuin yrität uudelleen',
    'token'     => 'Resetointitunniste on viallinen.',
    'user'      => 'Sähköpostiosoitteella ei löydy käyttäjää.',
];
