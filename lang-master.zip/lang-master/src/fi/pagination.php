<?php

return [
    'next'     => 'Seuraava &raquo;',
    'previous' => '&laquo; Edellinen',
];
