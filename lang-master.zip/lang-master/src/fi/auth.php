<?php

return [
    'failed'   => 'Kirjautuminen epäonnistui.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Liian monta kirjautumisyritystä. Yritä uudelleen :seconds sekunnin kuluttua.',
];
