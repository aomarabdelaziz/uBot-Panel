<?php

return [
    'failed'   => 'Rossz email-jelszó páros.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Túl sok próbálkozás. Kérjük próbálja újra :seconds másodperc múlva.',
];
