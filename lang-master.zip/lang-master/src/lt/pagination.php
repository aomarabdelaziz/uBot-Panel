<?php

return [
    'next'     => 'Kitas &raquo;',
    'previous' => '&laquo; Ankstesnis',
];
