<?php

return [
    'failed'   => 'Prisijungimo duomenys neatitinka.',
    'password' => 'Pateiktas slaptažodis yra neteisingas.',
    'throttle' => 'Per daug bandymų prisijungti. Bandykite po :seconds sec.',
];
