<?php

return [
    'reset'     => 'Nustatytas naujas slaptažodis!',
    'sent'      => 'Naujo slaptažodžio nustatymo nuoroda išsiųsta',
    'throttled' => 'Palaukite prieš tęsdami.',
    'token'     => 'Šis slaptažodžio raktas yra neteisingas.',
    'user'      => 'Vartotojas su tokiu el. paštu nerastas.',
];
