<?php

return [
    'failed'   => 'Ovi podaci se ne podudaraju s našim zapisima.',
    'password' => 'Navedena lozinka je netačna.',
    'throttle' => 'Previše neuspjelih pokušaja. Pokušajte ponovo za :seconds sekundi.',
];
