<?php

return [
    'next'     => 'Naprijed &raquo;',
    'previous' => '&laquo; Nazad',
];
