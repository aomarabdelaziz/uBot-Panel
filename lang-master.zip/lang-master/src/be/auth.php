<?php

return [
    'failed'   => 'Імя карыстальніка і пароль не супадаюць.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Занадта шмат спробаў ўваходу. Калі ласка, паспрабуйце яшчэ раз праз :seconds секунд.',
];
