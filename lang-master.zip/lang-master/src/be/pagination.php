<?php

return [
    'next'     => 'Наперад &raquo;',
    'previous' => '&laquo; Назад',
];
