<?php

return [
    'reset'     => 'Heslo bolo zmenené!',
    'sent'      => 'Pripomienka k zmene hesla bola odoslaná!',
    'throttled' => 'Pred ďalším pokusom chvíľu počkajte.',
    'token'     => 'Klúč pre obnovu hesla je neplatný.',
    'user'      => 'Nepodarilo sa nájsť používateľa s touto e-mailovou adresou.',
];
