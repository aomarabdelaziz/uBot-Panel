<?php

return [
    'failed'   => 'Prihlasovacie údaje nie sú správne.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Prekročený limit pokusov. Skúste znovu o :seconds sekúnd.',
];
