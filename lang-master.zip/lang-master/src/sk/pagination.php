<?php

return [
    'next'     => 'Nasledujúca &raquo;',
    'previous' => '&laquo; Predchádzajúca',
];
