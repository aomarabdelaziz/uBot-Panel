<?php

return [
    'failed'   => 'Deze combinatie van e-mailadres en wachtwoord is niet geldig.',
    'password' => 'Het opgegeven wachtwoord is onjuist.',
    'throttle' => 'Te veel mislukte loginpogingen. Probeer het over :seconds seconden nogmaals.',
];
