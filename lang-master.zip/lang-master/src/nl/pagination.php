<?php

return [
    'next'     => 'Volgende &raquo;',
    'previous' => '&laquo; Vorige',
];
