<?php

return [
    'reset'     => 'Het wachtwoord van uw account is gewijzigd.',
    'sent'      => 'We hebben een e-mail verstuurd met instructies om een nieuw wachtwoord in te stellen.',
    'throttled' => 'Gelieve even te wachten voor u het opnieuw probeert.',
    'token'     => 'Dit wachtwoordhersteltoken is niet geldig.',
    'user'      => 'Geen gebruiker bekend met het e-mailadres.',
];
