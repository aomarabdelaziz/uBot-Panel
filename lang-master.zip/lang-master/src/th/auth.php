<?php

return [
    'failed'   => 'ข้อมูลที่ใช้ในการยืนยันตัวตนไม่ถูกต้อง',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'คุณได้พยายามเข้าระบบหลายครั้งเกินไป กรุณาลองใหม่ใน :seconds วินาทีข้างหน้า.',
];
