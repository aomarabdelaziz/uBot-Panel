<?php

return [
    'next'     => 'ถัดไป &raquo;',
    'previous' => '&laquo; ก่อนหน้า',
];
