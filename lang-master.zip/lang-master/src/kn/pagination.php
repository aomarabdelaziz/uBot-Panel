<?php

return [
    'next'     => 'ಮುಂದಿನ &raquo;',
    'previous' => '&laquo; ಹಿಂದಿನ',
];
