<?php

return [
    'failed'   => 'Aquestes credencials no concorden amb els nostres registres.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Ha superat el nombre màxim d\'intents d\'accés. Si us plau, torni a intentar-ho en :seconds segons.',
];
