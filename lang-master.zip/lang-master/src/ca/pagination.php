<?php

return [
    'next'     => 'Següent &raquo;',
    'previous' => '&laquo; Anterior',
];
