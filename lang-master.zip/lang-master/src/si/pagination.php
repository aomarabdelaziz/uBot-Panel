<?php

return [
    'next'     => 'ඊළඟ &raquo;',
    'previous' => '&laquo; පෙර',
];
