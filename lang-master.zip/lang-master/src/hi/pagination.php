<?php

return [
    'next'     => 'अगला &raquo;',
    'previous' => '&laquo; पिछला',
];
