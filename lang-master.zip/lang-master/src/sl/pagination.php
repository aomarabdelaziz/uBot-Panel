<?php

return [
    'next'     => 'Naslednja &raquo;',
    'previous' => '&laquo; Prejšnja',
];
