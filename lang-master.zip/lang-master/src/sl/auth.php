<?php

return [
    'failed'   => 'Ti podatki se ne ujemajo z našimi.',
    'password' => 'Geslo ni pravilno.',
    'throttle' => 'Preveč poskusov prijave. Prosimo, poskusite ponovno čez :seconds sekund.',
];
