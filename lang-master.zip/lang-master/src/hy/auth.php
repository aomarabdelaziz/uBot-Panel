<?php

return [
    'failed'   => 'Մուտքագրված տվյալները սխալ են։',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Չափազանց շատ մուտք գործելու փորձեր։ Խնդրում ենք փորձել կրկին :seconds վայրկյան անց։',
];
