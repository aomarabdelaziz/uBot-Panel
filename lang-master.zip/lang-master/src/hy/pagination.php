<?php

return [
    'next'     => 'Հաջորդ &raquo;',
    'previous' => '&laquo; Նախորդ',
];
