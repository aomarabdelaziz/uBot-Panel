<?php

return [
    'next'     => 'A pustis &raquo;',
    'previous' => '&laquo; A in antis',
];
