<?php

return [
    'reset'     => 'Sa password est istada torrada a impostare!',
    'sent'      => 'Regordu de sa password imbiadu!',
    'throttled' => 'Please wait before retrying.',
    'token'     => 'Custu token pro torrare a impostare sa password no est bàlidu.',
    'user'      => 'Non s\'agatat un\'impitadore assotziadu a custu indiritzu email.',
];
