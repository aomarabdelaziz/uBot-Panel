<?php

return [
    'next'     => '下一頁 &raquo;',
    'previous' => '&laquo; 上一頁',
];
