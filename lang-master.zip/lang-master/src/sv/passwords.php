<?php

return [
    'reset'     => 'Lösenordet har blivit återställt!',
    'sent'      => 'Lösenordspåminnelse skickad!',
    'throttled' => 'Vänligen vänta innan du försöker igen.',
    'token'     => 'Koden för lösenordsåterställning är ogiltig.',
    'user'      => 'Det finns ingen användare med den e-postadressen.',
];
