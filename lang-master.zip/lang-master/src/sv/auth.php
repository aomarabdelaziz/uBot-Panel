<?php

return [
    'failed'   => 'Dessa uppgifter stämmer inte överens med vårt register.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'För många inloggningsförsök. Var vänlig försök igen om :seconds sekunder.',
];
