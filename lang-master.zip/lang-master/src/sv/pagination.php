<?php

return [
    'next'     => 'Nästa &raquo;',
    'previous' => '&laquo; Föregående',
];
