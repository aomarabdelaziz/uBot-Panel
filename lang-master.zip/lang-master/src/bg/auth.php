<?php

return [
    'failed'   => 'Неуспешно удостоверяване на потребител.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Твърде много опити за вход. Моля, опитайте отново след :seconds секунди.',
];
