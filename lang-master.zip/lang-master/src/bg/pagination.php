<?php

return [
    'next'     => 'Напред &raquo;',
    'previous' => '&laquo; Назад',
];
