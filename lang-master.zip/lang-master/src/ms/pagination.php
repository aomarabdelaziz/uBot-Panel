<?php

return [
    'next'     => 'Seterusnya &raquo;',
    'previous' => '&laquo; Sebelumnya',
];
