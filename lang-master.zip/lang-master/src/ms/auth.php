<?php

return [
    'failed'   => 'Butiran ini tidak sepadan dengan rekod kami.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Terlalu banyak percubaan log masuk. Sila cuba lagi dalam :seconds saat.',
];
