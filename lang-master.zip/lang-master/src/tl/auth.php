<?php

return [
    'failed'   => 'Ang credentials na ito ay hindi katugma ng nasa rekord namin.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Sobrang daming pagtatangkang mag-login. Pakisubukan ulit sa :segundo segundo.',
];
