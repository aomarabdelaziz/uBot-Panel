<?php

return [
    'next'     => 'Susunod &raquo;',
    'previous' => '&laquo; Nauna',
];
