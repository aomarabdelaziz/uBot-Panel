<?php

return [
    'reset'     => 'Na-reset na ang password mo!',
    'sent'      => 'Na-email na namin sa iyo ang link sa pag-reset ng password!',
    'throttled' => 'Please wait before retrying.',
    'token'     => 'Ang token sa pag-reset ng password na ito ay imbalido.',
    'user'      => 'Hindi namin mahanap ang user na may ganyang email address.',
];
