<?php

return [
    'failed'   => 'Datele de identificare nu pot fi confirmate.',
    'password' => 'Parola introdusă, nu este corectă.',
    'throttle' => 'Prea multe încercări de intrare în cont. Puteți încerca din nou peste :seconds secunde.',
];
