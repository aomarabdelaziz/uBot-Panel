<?php

return [
    'reset'     => 'Parola a fost resetată!',
    'sent'      => 'Am trimis un e-mail cu link-ul de resetare a parolei!',
    'throttled' => 'Please wait before retrying.',
    'token'     => 'Codul de resetare a parolei este greșit.',
    'user'      => 'Nu există niciun utilizator cu această adresă de e-mail.',
];
