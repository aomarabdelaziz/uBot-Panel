<?php

return [
    'next'     => 'Înainte &raquo;',
    'previous' => '&laquo; Înapoi',
];
