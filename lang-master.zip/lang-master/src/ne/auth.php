<?php

return [
    'failed'   => 'यी प्रमाणहरू हाम्रो रेकर्ड संग मेल खादैनन्।',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'धेरै लगिन प्रयास भयो :seconds सेकेन्ड पछि फेरि प्रयास गर्नुहोस्।',
];
