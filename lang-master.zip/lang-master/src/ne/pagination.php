<?php

return [
    'next'     => 'अर्को &raquo;',
    'previous' => '&laquo; अघिल्लो',
];
