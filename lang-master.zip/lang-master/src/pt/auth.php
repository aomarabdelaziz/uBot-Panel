<?php

return [
    'failed'   => 'As credenciais indicadas não coincidem com as registadas no sistema.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'O número limite de tentativas de login foi atingido. Por favor tente novamente dentro de :seconds segundos.',
];
