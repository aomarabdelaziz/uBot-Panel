<?php

return [
    'reset'     => 'Das Passwort wurde zurückgesetzt!',
    'sent'      => 'Passworterinnerung wurde gesendet!',
    'throttled' => 'Bitte warten Sie, bevor Sie es erneut versuchen.',
    'token'     => 'Der Passwort-Wiederherstellungs-Schlüssel ist ungültig oder abgelaufen.',
    'user'      => 'Es konnte leider kein Nutzer mit dieser E-Mail-Adresse gefunden werden.',
];
