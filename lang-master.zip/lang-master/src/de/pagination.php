<?php

return [
    'next'     => 'Weiter &raquo;',
    'previous' => '&laquo; Zurück',
];
