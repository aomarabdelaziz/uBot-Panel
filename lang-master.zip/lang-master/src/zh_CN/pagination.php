<?php

return [
    'next'     => '下一页 &raquo;',
    'previous' => '&laquo; 上一页',
];
