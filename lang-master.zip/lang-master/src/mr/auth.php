<?php

return [
    'failed'   => 'हे खाते वैध नाही.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'प्रवेशाचा जास्त वेळा प्रयत्न. :seconds सेकंड नंतर पुन्हा प्रयत्न करा.',
];
