<?php

return [
    'next'     => 'पुढचा &raquo;',
    'previous' => '&laquo; मागचा',
];
