<?php

return [
    'failed'   => 'قوللانچى نامى ياكى پارولدا خاتالىق بار.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'مەشغۇلات قېتىم سانى بەك كۆپ بۇلۇپ كەتتى، يەنە :seconds سېكۇنتتىن كىيىن قايتا سىناپ بېقىڭ.',
];
