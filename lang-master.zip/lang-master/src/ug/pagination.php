<?php

return [
    'next'     => 'كىيىنكى بەت &raquo;',
    'previous' => '&laquo; ئالدىنقى بەت',
];
