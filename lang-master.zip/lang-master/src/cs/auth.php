<?php

return [
    'failed'   => 'Tyto přihlašovací údaje neodpovídají žadnému záznamu.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Příliš mnoho pokusů o přihlášení. Zkuste to prosím znovu za :seconds vteřin.',
];
