<?php

return [
    'next'     => 'další &raquo;',
    'previous' => '&laquo; předchozí',
];
