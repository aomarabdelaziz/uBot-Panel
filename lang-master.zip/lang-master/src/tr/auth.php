<?php

return [
    'failed'   => 'Bu kimlik bilgileri kayıtlarımızla eşleşmiyor.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Çok fazla giriş denemesi. :seconds saniye sonra lütfen tekrar deneyin.',
];
