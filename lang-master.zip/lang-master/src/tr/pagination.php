<?php

return [
    'next'     => 'Sonrakiler &raquo;',
    'previous' => '&laquo; Öncekiler',
];
