<?php

return [
    'next'     => 'Neste &raquo;',
    'previous' => '&laquo; Forrige',
];
