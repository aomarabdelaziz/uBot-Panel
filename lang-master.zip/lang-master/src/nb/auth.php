<?php

return [
    'failed'   => 'Disse opplysningene samsvarer ikke med hva vi har lagret.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'For mange innloggingsforsøk. Vennligst prøv igjen om :seconds sekunder.',
];
