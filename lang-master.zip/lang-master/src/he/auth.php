<?php

return [
    'failed'   => 'פרטים אלה אינם תואמים את רישומינו.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'ניסיונות כניסה רבים מדי. אנא נסו שוב בעוד :seconds שניות.',
];
