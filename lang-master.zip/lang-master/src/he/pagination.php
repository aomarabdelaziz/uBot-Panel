<?php

return [
    'next'     => 'הבא &raquo;',
    'previous' => '&laquo; הקודם',
];
