<?php

return [
    'failed'   => 'এই পরিচয়পত্র আমাদের রেকর্ডের সাথে মেলে না.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'লগইন করার জন্য অনেকগুলি চেষ্টা করেছেন. :seconds সেকেন্ড পরে আবার চেষ্টা করুন .',
];
