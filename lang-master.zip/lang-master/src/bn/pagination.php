<?php

return [
    'next'     => 'পরবর্তী &raquo;',
    'previous' => '&laquo; আগে',
];
