<?php

return [
    'next'     => 'Επόμενη &raquo;',
    'previous' => '&laquo; Προηγούμενη',
];
