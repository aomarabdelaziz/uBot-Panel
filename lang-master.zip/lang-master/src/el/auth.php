<?php

return [
    'failed'   => 'Τα στοιχεία αυτά δεν ταιριάζουν με τα δικά μας.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Πολλές προσπάθειες σύνδεσης. Παρακαλώ δοκιμάστε ξανά σε :seconds δευτερόλεπτα.',
];
