<?php

return [
    'reset'     => 'Lykilorðið þitt hefur verið endurstillt!',
    'sent'      => 'Við sendum þér tölvupóst með slóð til að endurheimta lykilorðið þitt.',
    'throttled' => 'Please wait before retrying.',
    'token'     => 'Kóðinn til að endurheimta lykilorðið er rangur.',
    'user'      => 'Notandi með þetta netfang finnst ekki.',
];
