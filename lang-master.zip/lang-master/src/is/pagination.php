<?php

return [
    'next'     => 'Næsta &raquo;',
    'previous' => '&laquo; Fyrri',
];
