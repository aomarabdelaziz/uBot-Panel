<?php

return [
    'next'     => 'Кейинги &raquo;',
    'previous' => '&laquo; Олдинги',
];
