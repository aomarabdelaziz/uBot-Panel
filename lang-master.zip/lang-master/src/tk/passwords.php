<?php

return [
    'reset'     => 'Açarsöz üýtgedildi!',
    'sent'      => 'Açarsöz ýatlatmasy ugradyldy!',
    'throttled' => 'Please wait before retrying.',
    'token'     => 'Açarsöz tazeleme söz birligi ýalňyş.',
    'user'      => 'Bu e-mail adrese degişli ulanyjy tapylmady.',
];
