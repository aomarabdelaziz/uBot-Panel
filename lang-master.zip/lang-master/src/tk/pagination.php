<?php

return [
    'next'     => 'Indiki &raquo;',
    'previous' => '&laquo; Öňki',
];
