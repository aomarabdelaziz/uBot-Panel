<?php

return [
    'next'     => 'შემდეგი &raquo;',
    'previous' => '&laquo; წინა',
];
