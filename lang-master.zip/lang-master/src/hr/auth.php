<?php

return [
    'failed'   => 'Ovi podaci ne odgovaraju našima.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Previše pokušaja prijave. Molim Vas pokušajte ponovno za :seconds sekundi.',
];
