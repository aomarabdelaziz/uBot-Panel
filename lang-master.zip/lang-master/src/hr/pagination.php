<?php

return [
    'next'     => 'Sljedeća &raquo;',
    'previous' => '&laquo; Prethodna',
];
