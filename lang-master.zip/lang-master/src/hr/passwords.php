<?php

return [
    'reset'     => 'Lozinka je postavljena!',
    'sent'      => 'Poveznica za ponovono postavljanje lozinke je poslana!',
    'throttled' => 'Molimo pričekajte prije ponovnog pokušaja!',
    'token'     => 'Oznaka za ponovno postavljanje lozinke više nije važeća.',
    'user'      => 'Korisnik nije pronađen.',
];
