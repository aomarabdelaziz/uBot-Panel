<?php

return [
    'failed'   => 'İstifadəçi adı və ya şifrə səhvdir',
    'password' => 'The provided password is incorrect.',
    'throttle' => ':seconds saniyə ərzində yenidən cəhd edin',
];
