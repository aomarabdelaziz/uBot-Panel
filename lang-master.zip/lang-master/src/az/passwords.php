<?php

return [
    'reset'     => 'Şifrə yeniləndi',
    'sent'      => 'Şifrə yeniləmə adresi sizə email olaraq göndərildi',
    'throttled' => 'Please wait before retrying.',
    'token'     => 'Bu şifrə yeniləmə kodu yanlışdır',
    'user'      => 'Bu email\'ə uyğun istifadəçi tapılmadı',
];
