<?php

return [
    'next'     => 'Sonra &raquo;',
    'previous' => '&laquo; Əvvəl',
];
