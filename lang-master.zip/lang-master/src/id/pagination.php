<?php

return [
    'next'     => 'Berikutnya &raquo;',
    'previous' => '&laquo; Sebelumnya',
];
