<?php

return [
    'failed'   => 'Identitas tersebut tidak cocok dengan data kami.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Terlalu banyak upaya masuk. Silahkan coba lagi dalam :seconds detik.',
];
