<?php

return [
    'reset'     => 'Zure pasahitza berrezarri da!',
    'sent'      => 'Zure pasahitza berrezartzeko esteka postaz bidali dizugu!',
    'throttled' => 'Please wait before retrying.',
    'token'     => 'Pasahitza berreskuratzeko tokena baliogabea da.',
    'user'      => 'Ezin izan dugu helbide elektroniko horrekin bat datorren erabiltzailerik aurkitu.',
];
