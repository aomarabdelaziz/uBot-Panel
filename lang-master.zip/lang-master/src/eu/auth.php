<?php

return [
    'failed'   => 'Kredentzial hauek ez datoz bat gure erregistroekin.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Atzipen saialdi gehiegi. Mesedez berriro saiatu :seconds segundo barru.',
];
