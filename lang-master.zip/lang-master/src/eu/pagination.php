<?php

return [
    'next'     => 'Hurrengoa &raquo;',
    'previous' => '&laquo; Aurrekoa',
];
