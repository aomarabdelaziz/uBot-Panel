<?php

return [
    'reset'     => 'Sizning parolingiz tiklandi!',
    'sent'      => 'Parolni tiklash havolasini elektron pochta orqali yubordik!',
    'throttled' => 'Iltimos birozdan so‘ng qayta urinib ko‘ring.',
    'token'     => 'Ushbu parolni qayta tiklash kodi noto‘g‘ri.',
    'user'      => 'Ushbu elektron pochta manziliga ega foydalanuvchi topilmadi.',
];
