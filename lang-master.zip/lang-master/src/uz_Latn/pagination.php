<?php

return [
    'next'     => 'Keyingi &raquo;',
    'previous' => '&laquo; Oldingi',
];
