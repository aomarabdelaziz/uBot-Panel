<?php

return [
    'failed'   => 'Bunday maʼlumotlarga ega foydalanuvchi mavjud emas.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Kirish uchun juda ko‘p urinishlar aniqlandi. Iltimos :seconds soniyadan so‘ng yana urinib ko‘ring.',
];
