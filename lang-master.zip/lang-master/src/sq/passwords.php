<?php

return [
    'reset'     => 'Fjalëkalimi u ndryshua!',
    'sent'      => 'Adresa për ndryshimin e fjalëkalimit u dërgua!',
    'throttled' => 'Ju lutemi prisni para se të provoni përsëri.',
    'token'     => 'Ky tallon për ndryshimin e fjalëkalimit është i pasaktë.',
    'user'      => 'Nuk mund të gjejmë një përdorues me atë adresë email-i.',
];
