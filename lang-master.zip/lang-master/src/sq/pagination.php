<?php

return [
    'next'     => 'Para &raquo;',
    'previous' => '&laquo; Prapa',
];
