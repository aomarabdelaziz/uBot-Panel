<?php

return [
    'next'     => 'بل &raquo;',
    'previous' => '&laquo; مخکې',
];
