<?php

return [
    'next'     => 'បន្ទាប់ &raquo;',
    'previous' => '&laquo; មុន',
];
