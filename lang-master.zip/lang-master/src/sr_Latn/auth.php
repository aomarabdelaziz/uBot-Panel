<?php

return [
    'failed'   => 'Podaci ne odgovaraju ni jednom nalogu.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Previše neuspelih pokušaja. Pokušajte ponovo za :seconds sekundi.',
];
