<?php

return [
    'next'     => 'Napred &raquo;',
    'previous' => '&laquo; Nazad',
];
