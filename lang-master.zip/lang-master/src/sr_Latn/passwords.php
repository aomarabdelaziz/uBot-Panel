<?php

return [
    'reset'     => 'Lozinka je resetovana!',
    'sent'      => 'Poslali smo reset link za vašu lozinku!',
    'throttled' => 'Molimo sačekajte pre nego sto pokušate ponovo.',
    'token'     => 'Ukucana oznaka za resetovanje lozinke nije važeća.',
    'user'      => 'Nismo uspeli pronaći korisnika sa email adresom.',
];
