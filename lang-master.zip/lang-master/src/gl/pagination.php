<?php

return [
    'next'     => 'Seguinte &raquo;',
    'previous' => '&laquo; Anterior',
];
