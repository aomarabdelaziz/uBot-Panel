<?php

return [
    'failed'   => 'Estas credenciais non coinciden cos nosos rexistros.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Demasiados intentos de acceso. Por favor, inténtao de novo en :seconds segundos.',
];
