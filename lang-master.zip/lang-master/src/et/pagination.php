<?php

return [
    'next'     => 'Järgmine &raquo;',
    'previous' => '&laquo; Eelmine',
];
