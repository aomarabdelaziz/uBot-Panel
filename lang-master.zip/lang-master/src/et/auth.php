<?php

return [
    'failed'   => 'Need andmed ei klapi meie kirjetega.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Liiga palju sisselogimise katseid. Palun proovi uuesti :seconds sekundi pärast.',
];
