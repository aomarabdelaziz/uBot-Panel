<?php

return [
    'failed'   => 'یہ تفصیلات ہمارے ریکارڈ سے مطابقت نہیں رکھتیں۔',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'لاگ اِن کرنے کی بہت زیادہ کوششیں۔ براہِ مہربانی :seconds سیکنڈ میں دوبارہ کوشش کریں۔',
];
