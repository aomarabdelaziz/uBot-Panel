<?php

return [
    'next'     => 'آئندہ &raquo;',
    'previous' => '&laquo; گزشتہ',
];
