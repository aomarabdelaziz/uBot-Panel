<?php

return [
    'failed'   => 'Hii hati tambulishi hailingani na rekodi zetu.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Majaribio mengi sana ya kuingia. Tafadhali jaribu tena katika :sekunde sekunde.',
];
