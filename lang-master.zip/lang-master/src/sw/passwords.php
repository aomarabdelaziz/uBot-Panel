<?php

return [
    'reset'     => 'Nenosiri lako limefufuliwa upya!',
    'sent'      => 'Tumekutumia barua pepe ya fungo la kufufua nenosiri!',
    'throttled' => 'Please wait before retrying.',
    'token'     => 'Huu ufufuzi wa nenosiri si halali.',
    'user'      => 'Hatupati mtumiaji wa hiyo anuani ya barua pepe.',
];
