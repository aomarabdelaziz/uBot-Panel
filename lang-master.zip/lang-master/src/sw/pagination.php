<?php

return [
    'next'     => 'Ifuatayo na raquo;',
    'previous' => 'na laquo; Awali',
];
