<?php

return [
    'reset'     => 'Jūsu parole ir atjaunināta!',
    'sent'      => 'Mēs nosūtījām paroles maiņas linku uz jūsu e-pastu!',
    'throttled' => 'Please wait before retrying.',
    'token'     => 'Šāda zīme pie paroles maiņas nav atļauta.',
    'user'      => 'Mēs nevaram atrast lietotāju ar tādu e-pasta adresi.',
];
