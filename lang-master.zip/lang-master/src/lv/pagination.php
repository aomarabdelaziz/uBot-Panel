<?php

return [
    'next'     => 'Nākamais &raquo;',
    'previous' => '&laquo; Iepriekšējais',
];
