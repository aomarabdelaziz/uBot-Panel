<?php

return [
    'next'     => 'sljedeća &raquo;',
    'previous' => '&laquo; prethodna',
];
