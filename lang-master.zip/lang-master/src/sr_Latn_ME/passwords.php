<?php

return [
    'reset'     => 'Lozinka je resetovana.',
    'sent'      => 'Poslali smo vam e-mail sa uputstvom kako da resetujete lozinku.',
    'throttled' => 'Molimo sačekajte prije nego što pokušate ponovo.',
    'token'     => 'Link za resetovanje lozinke nije ispravan.',
    'user'      => 'Nepostojeći korisnik.',
];
