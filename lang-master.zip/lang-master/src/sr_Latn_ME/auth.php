<?php

return [
    'failed'   => 'Podaci ne odgovaraju ni jednom nalogu.',
    'password' => 'Neispravna lozinka.',
    'throttle' => 'Previše neuspelih pokušaja. Pokušajte ponovo za :seconds sekundi.',
];
