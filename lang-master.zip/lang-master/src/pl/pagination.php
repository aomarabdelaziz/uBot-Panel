<?php

return [
    'next'     => 'Następna &raquo;',
    'previous' => '&laquo; Poprzednia',
];
