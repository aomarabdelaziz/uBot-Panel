<?php

return [
    'failed'   => 'Aqueles identificants correspondon pas a nòstres enregistraments.',
    'password' => 'Lo senhal provesit es pas corrèct.',
    'throttle' => 'Tròp d’ensages de connexion. Tornatz ensajar d’aquí :seconds segondas.',
];
