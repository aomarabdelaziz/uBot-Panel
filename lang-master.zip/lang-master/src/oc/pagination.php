<?php

return [
    'next'     => 'Seguent &raquo;',
    'previous' => '&laquo; Predecent',
];
