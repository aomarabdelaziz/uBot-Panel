<?php

return [
    'next'     => 'Nesaf &raquo;',
    'previous' => '&laquo; Cynt',
];
