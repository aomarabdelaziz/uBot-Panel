<?php

return [
    'next'     => 'Successivo &raquo;',
    'previous' => '&laquo; Precedente',
];
