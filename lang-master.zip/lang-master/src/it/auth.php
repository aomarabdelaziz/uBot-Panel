<?php

return [
    'failed'   => 'Credenziali non valide.',
    'password' => 'La password non è valida.',
    'throttle' => 'Troppi tentativi di accesso. Riprova tra :seconds secondi.',
];
