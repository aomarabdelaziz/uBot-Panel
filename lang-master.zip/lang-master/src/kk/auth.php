<?php

return [
    'failed'   => 'Тіркелгі деректері біздің жазбаларымызға сай емес.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Кіру әрекеті тым көп болды. :seconds секундтан соң қайталап көріңіз.',
];
