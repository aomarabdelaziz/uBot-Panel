<?php

return [
    'next'     => 'Келесі &raquo;',
    'previous' => '&laquo; Алдыңғы',
];
