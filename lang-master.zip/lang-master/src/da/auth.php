<?php

return [
    'failed'   => 'De angivne oplysninger er ugyldige.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'For mange loginforsøg. Prøv igen om :seconds sekunder.',
];
