<?php

return [
    'next'     => 'Næste &raquo;',
    'previous' => '&laquo; Forrige',
];
