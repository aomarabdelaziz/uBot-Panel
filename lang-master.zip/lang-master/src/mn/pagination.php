<?php

return [
    'next'     => 'Дараах &raquo;',
    'previous' => '&laquo; Өмнөх',
];
