<?php

return [
    'failed'   => 'Хэрэглэгчийн нэр эсвэл нууц үг буруу.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Олон удаагийн буруу оролдого. :seconds секундийн дараа дахин оролдоно уу.',
];
