<?php

return [
    'failed'   => 'Подаци не одговарају ни једном налогу.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Превише неуспелих покушаја. Покушајте поново за :seconds секунди.',
];
