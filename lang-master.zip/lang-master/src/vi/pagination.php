<?php

return [
    'next'     => 'Trang trước &raquo;',
    'previous' => '&laquo; Trang sau',
];
