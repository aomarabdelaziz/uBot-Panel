<?php

return [
    'next'     => '다음 &raquo;',
    'previous' => '&laquo; 이전',
];
