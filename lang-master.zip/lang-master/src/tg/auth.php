<?php

return [
    'failed'   => 'Номи истифодабаранда ва гузарвожа нодуруст мебошад.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Теъдоди зиёди талош барои воридшудан ба система. Лутфан баъд аз :seconds сония боз кӯшиш намоед.',
];
