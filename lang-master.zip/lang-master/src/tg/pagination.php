<?php

return [
    'next'     => 'Баъдӣ &raquo;',
    'previous' => '&laquo; Қаблӣ',
];
