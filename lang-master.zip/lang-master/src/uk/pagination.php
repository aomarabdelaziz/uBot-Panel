<?php

return [
    'next'     => 'Далі &raquo;',
    'previous' => '&laquo; Назад',
];
