<?php

return [
    'failed'   => 'Credenciais informadas não correspondem com nossos registros.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Você realizou muitas tentativas de login. Por favor, tente novamente em :seconds segundos.',
];
